
public interface MoniteurListenerA extends MoniteurListener{
	
	public void onEvent(incendies e);

}
