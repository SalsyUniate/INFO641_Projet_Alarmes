
public interface MoniteurListener {

	public void onEvent(gaz_toxiques e);

}
