
public interface MoniteurListenerB extends MoniteurListener{
	
	public void onEvent(radiations e);

}
