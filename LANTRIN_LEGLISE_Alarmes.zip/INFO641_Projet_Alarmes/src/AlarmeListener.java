
public interface AlarmeListener {
	
	public void newAlarme(AlarmeEvent alarme);
}
