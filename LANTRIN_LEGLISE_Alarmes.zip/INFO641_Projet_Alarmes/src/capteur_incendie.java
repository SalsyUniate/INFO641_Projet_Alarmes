
public class capteur_incendie extends Capteurs{

	public capteur_incendie(String date, String localisation, String nvImportance) {
		super(date, localisation, nvImportance);
		// TODO Auto-generated constructor stub
	}
	
	

}
