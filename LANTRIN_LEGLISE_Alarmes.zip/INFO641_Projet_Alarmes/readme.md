INFO641 - PROJET ALARMES 

Le code principal à exécuter se trouve dans le fichier "main". 

Nous avons mis au point la partie "à l'essentiel" du sujet et commencé la partie fonctionnelle, cependant un problème d'affichage (un problème de rafraîchissement de la page ou de la liste peut-être ?) nous a empêchées de continuer. Nous avons essayé plusieurs commandes de rafraîchissement, sans succès. 

LANTRIN Sarah
LÉGLISE Cloé 
SNI3 - E2